# Hangproef koppelen aan Google Drive en Sheets

Na deze stappen hoef je nieuwe schilderijen alleen nog maar in een Drive-map te
zetten: ze staan dan vanzelf in de galerij. En wat bezoekers in het
contactformulier invullen, komt in een spreadsheet te staan.

Reken op een kwartier, eenmalig.

---

## 1. Drive-map maken

1. Ga naar drive.google.com en maak een map, bijvoorbeeld **Werken Hangproef**.
2. Zet daar de foto's van de schilderijen in.
3. Noem de bestanden volgens dit patroon:

   ```
   Ochtendgloren - acryl op linnen - 50x70.jpg
   ```

   * vóór het eerste streepje: de **titel**
   * daartussen: de **techniek** (mag weg)
   * achteraan: **breedte x hoogte in centimeters** (mag weg)

   `Duinwind - 60x80.jpg` en `Duinwind.jpg` werken dus ook. Staat er geen maat
   bij, dan gebruikt de pagina de verhouding van de foto met 60 cm breed.

4. Open de map en kopieer het middelste stuk uit de adresbalk — dat is de
   **map-ID**:

   ```
   https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQr
                                          ^^^^^^^^^^^^^^^^^^^^
   ```

## 2. Spreadsheet maken

1. Ga naar sheets.google.com en maak een nieuw spreadsheet, bijvoorbeeld
   **Aanvragen Hangproef**. Verder hoef je er niets in te zetten.

## 3. Het script erin zetten

1. Klik in dat spreadsheet op **Extensies → Apps Script**.
2. Verwijder alles wat er staat en plak de volledige inhoud van `Code.gs`.
3. Vul bovenin in:
   * `MAP_ID` — de map-ID uit stap 1
   * `MELD_AAN` — je e-mailadres als je een seintje wilt bij elke aanvraag
     (of laat het leeg)
4. Klik op het opslaan-icoon.

## 4. Publiceren als webapp

1. Klik rechtsboven op **Implementeren → Nieuwe implementatie**.
2. Klik op het tandwiel naast "Type selecteren" en kies **Web-app**.
3. Vul in:
   * *Uitvoeren als*: **Ik** (jouw account)
   * *Wie heeft toegang*: **Iedereen**
4. Klik op **Implementeren**. Google vraagt eenmalig om toestemming: doorlopen
   en toestaan. Zie je een waarschuwing "Deze app is niet geverifieerd", klik
   dan op **Geavanceerd → Ga naar ... (onveilig)** — dit is je eigen script.
5. Kopieer de **web-app-URL**. Die eindigt op `/exec`.

## 5. Koppelen in de tool

1. Open `atelier.html` op je eigen computer.
2. Tik vijf keer op de titel bovenaan (of zet `?atelier` achter het adres) om
   het beheer te openen.
3. Plak de web-app-URL bij **Google-koppeling** en klik op **Teksten opslaan**.
4. Klik op **Bezoekerspagina opslaan (index.html)** en upload dat bestand naar
   GitHub (Add file → Upload files → Commit changes).

Klaar. De pagina haalt de werken nu uit je Drive-map en zet aanvragen in je
spreadsheet.

---

## Wat er in het spreadsheet komt

Het script maakt de tabbladen zelf aan zodra er iets binnenkomt:

| Tabblad | Wat erin staat |
| --- | --- |
| **Aanschaf** | Aanvragen via "Contact voor aanschaf" |
| **Kantoor** | Aanvragen via "Iedere maand ander werk op kantoor" |
| **Logboek** | Ruwe bezoekgegevens, één regel per gebeurtenis |
| **Statistieken** | Samenvatting, werkt automatisch bij |

Op het tabblad **Statistieken** staan: paginabezoeken, unieke bezoekers,
nieuwe en terugkerende bezoekers, gemiddelde en langste tijd op de pagina,
het aantal aanvragen per soort, hoe vaak elk blok geopend is en welke
schilderijen het vaakst aan een muur zijn bekeken.

Die tellingen zijn formules op het Logboek. Het Logboek zelf mag je laten
staan; verwijder je regels, dan lopen de cijfers mee terug.

### Over de bezoekcijfers

De pagina bewaart een willekeurig nummer in de browser van de bezoeker om
terugkerend bezoek te herkennen. Er worden geen namen, IP-adressen of andere
persoonsgegevens vastgelegd — alleen tellingen. Wil je helemaal zeker zijn dat
het aan de AVG voldoet, zet er dan een regel over in een privacyverklaring op de
pagina; vraag me gerust die tekst te schrijven.

## Daarna

* **Nieuw werk erbij?** Foto in de Drive-map zetten, klaar. Niets uploaden.
* **Werk verkocht?** Foto uit de map halen of naar een submap verplaatsen.
* **Volgorde aanpassen?** De pagina sorteert op bestandsnaam. Zet er
  desnoods `01 `, `02 ` voor.
* **Script aangepast?** Na elke wijziging opnieuw **Implementeren → Implementatie
  beheren → potloodje → Versie: Nieuwe versie → Implementeren**, anders blijft de
  oude versie draaien.

## Als er iets niet werkt

* **Galerij toont nog de oude werken**: de pagina valt terug op wat er in het
  bestand zit als de koppeling niet antwoordt. Controleer of de web-app-URL op
  `/exec` eindigt en of *Wie heeft toegang* op **Iedereen** staat.
* **Foto's blijven grijs**: de map-ID klopt niet, of de bestanden zijn geen
  gewone afbeeldingen (jpg, png, webp).
* **Formulier zegt dat versturen niet lukt**: open de web-app-URL zelf in je
  browser. Zie je een lijst met werken in tekstvorm, dan doet het script het;
  zie je een foutmelding, dan staat de implementatie nog niet op "Iedereen".
