/**
 * Hangproef — koppeling met Google Drive en Google Sheets
 *
 * Wat dit script doet:
 *  1. Het geeft de pagina de lijst met foto's uit één Drive-map (de werken).
 *  2. Het levert elke foto verkleind aan de pagina.
 *  3. Het schrijft aanvragen weg in aparte tabbladen:
 *       "Aanschaf"  — vragen over het kopen van een werk
 *       "Kantoor"   — vragen over het maandabonnement voor bedrijven
 *  4. Het houdt bezoek bij in "Logboek" en vat dat samen in "Statistieken".
 *
 * Zie INSTALLATIE.md voor de stappen. Alleen de regels onder INSTELLINGEN
 * hoef je aan te passen.
 */

// ---------------------------------------------------------------------------
// INSTELLINGEN
// ---------------------------------------------------------------------------

// De ID van de Drive-map met de foto's van de werken.
// Open de map in Drive en kijk in de adresbalk:
// https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQr  <-- dit deel
var MAP_ID = 'ZET-HIER-DE-ID-VAN-JE-DRIVE-MAP';

// Heb je dit script gemaakt vanuit het spreadsheet zelf
// (Extensies -> Apps Script)? Laat dit dan leeg.
// Is het een los script (via script.google.com)? Zet hier dan de ID van je
// spreadsheet, het stuk tussen /d/ en /edit uit de adresbalk:
// https://docs.google.com/spreadsheets/d/1AbCdEfGhIjKlMnOpQr/edit
var SHEET_ID = '';

// E-mailadres dat een seintje krijgt bij een nieuwe aanvraag.
// Laat leeg ('') als je geen mail wilt.
var MELD_AAN = '';

// ---------------------------------------------------------------------------
// Vanaf hier hoef je niets meer te wijzigen
// ---------------------------------------------------------------------------

var BLAD_AANSCHAF = 'Aanschaf';
var BLAD_KANTOOR = 'Kantoor';
var BLAD_LOGBOEK = 'Logboek';
var BLAD_STATS = 'Statistieken';

var KOPPEN_AANVRAAG = ['Datum', 'Naam', 'E-mail', 'Telefoon', 'Werk', 'Bericht', 'Pagina'];
var KOPPEN_LOGBOEK = ['Datum', 'Bezoeker', 'Sessie', 'Type', 'Detail', 'Status', 'Seconden'];

function doGet(e) {
  var actie = (e && e.parameter && e.parameter.actie) || 'werken';

  if (actie === 'foto') {
    return foto(e.parameter.id);
  }
  return jsonAntwoord(werkenLijst());
}

function doPost(e) {
  try {
    var p = leesParameters(e);
    var soort = p.soort || 'aanschaf';

    if (soort === 'stat') {
      return jsonAntwoord(logRegel(p));
    }

    var bladNaam = (soort === 'kantoor') ? BLAD_KANTOOR : BLAD_AANSCHAF;
    var blad = zoekBlad(bladNaam, KOPPEN_AANVRAAG);

    blad.appendRow([
      new Date(),
      p.naam || '',
      p.email || '',
      p.telefoon || '',
      p.werk || '',
      p.bericht || '',
      p.pagina || ''
    ]);

    if (MELD_AAN) {
      MailApp.sendEmail({
        to: MELD_AAN,
        subject: 'Hangproef — nieuwe aanvraag (' + bladNaam.toLowerCase() + ')' +
                 (p.werk ? ': ' + p.werk : ''),
        body: 'Naam: ' + (p.naam || '-') +
              '\nE-mail: ' + (p.email || '-') +
              '\nTelefoon: ' + (p.telefoon || '-') +
              '\nWerk: ' + (p.werk || '-') +
              '\n\n' + (p.bericht || '')
      });
    }

    return jsonAntwoord({ ok: true, blad: bladNaam });
  } catch (fout) {
    return jsonAntwoord({ ok: false, fout: String(fout) });
  }
}

/** Bezoekgegevens wegschrijven in het logboek. */
function logRegel(p) {
  var blad = zoekBlad(BLAD_LOGBOEK, KOPPEN_LOGBOEK);
  blad.appendRow([
    new Date(),
    p.bezoeker || '',
    p.sessie || '',
    p.type || '',
    p.detail || '',
    p.status || '',
    Number(p.seconden || 0)
  ]);
  maakStatistieken();
  return { ok: true };
}

/** Werkt met gewone formulieren én met sendBeacon (platte tekst). */
function leesParameters(e) {
  if (e && e.parameter && Object.keys(e.parameter).length) return e.parameter;

  var uit = {};
  if (e && e.postData && e.postData.contents) {
    e.postData.contents.split('&').forEach(function (deel) {
      var stuk = deel.split('=');
      var sleutel = decodeURIComponent((stuk[0] || '').replace(/\+/g, ' '));
      var waarde = decodeURIComponent((stuk[1] || '').replace(/\+/g, ' '));
      if (sleutel) uit[sleutel] = waarde;
    });
  }
  return uit;
}

/** Alle afbeeldingen uit de map, op naam gesorteerd. */
function werkenLijst() {
  var map = DriveApp.getFolderById(MAP_ID);
  var bestanden = map.getFiles();
  var uit = [];

  while (bestanden.hasNext()) {
    var f = bestanden.next();
    if (f.getMimeType().indexOf('image/') !== 0) continue;
    uit.push({ id: f.getId(), naam: f.getName() });
  }

  uit.sort(function (a, b) { return a.naam.localeCompare(b.naam, 'nl'); });
  return { werken: uit };
}

/** Eén foto als data-url, verkleind zodat de pagina snel laadt. */
function foto(id) {
  var data = '';
  try {
    var klein = UrlFetchApp.fetch(
      'https://drive.google.com/thumbnail?id=' + id + '&sz=w1400',
      { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true }
    );
    if (klein.getResponseCode() === 200) {
      var blob = klein.getBlob();
      data = 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes());
    }
  } catch (fout) {
    data = '';
  }

  if (!data) {
    var orig = DriveApp.getFileById(id).getBlob();
    data = 'data:' + orig.getContentType() + ';base64,' + Utilities.base64Encode(orig.getBytes());
  }

  return ContentService.createTextOutput(data).setMimeType(ContentService.MimeType.TEXT);
}

function bestand() {
  var doc = SHEET_ID
    ? SpreadsheetApp.openById(SHEET_ID)
    : SpreadsheetApp.getActiveSpreadsheet();
  if (!doc) {
    throw new Error('Geen spreadsheet gevonden. Vul SHEET_ID in bovenaan dit script.');
  }
  return doc;
}

function zoekBlad(naam, koppen) {
  var doc = bestand();
  var blad = doc.getSheetByName(naam);

  if (!blad) {
    blad = doc.insertSheet(naam);
  }
  if (koppen && blad.getLastRow() === 0) {
    blad.appendRow(koppen);
    blad.getRange(1, 1, 1, koppen.length).setFontWeight('bold');
    blad.setFrozenRows(1);
  }
  return blad;
}

/** Overzichtsblad met formules; wordt één keer aangemaakt. */
function maakStatistieken() {
  var doc = bestand();
  if (doc.getSheetByName(BLAD_STATS)) return;

  var blad = doc.insertSheet(BLAD_STATS);
  var L = BLAD_LOGBOEK;

  blad.getRange('A1').setValue('Statistieken Hangproef').setFontWeight('bold').setFontSize(14);
  blad.getRange('A2').setValue('Werkt automatisch bij; het Logboek-tabblad is de bron.');

  var regels = [
    ['Paginabezoeken (openingen)', '=COUNTIF(' + L + '!D:D,"pagina")'],
    ['Unieke bezoekers', '=IFERROR(COUNTUNIQUE(' + L + '!B2:B),0)'],
    ['Terugkerende bezoekers', '=IFERROR(COUNTUNIQUE(FILTER(' + L + '!B2:B,' + L + '!F2:F="terugkerend")),0)'],
    ['Nieuwe bezoekers', '=IFERROR(COUNTUNIQUE(FILTER(' + L + '!B2:B,' + L + '!F2:F="nieuw")),0)'],
    ['Gemiddelde tijd op de pagina (minuten)', '=IFERROR(ROUND(AVERAGE(FILTER(' + L + '!G2:G,' + L + '!D2:D="duur"))/60,1),0)'],
    ['Langste bezoek (minuten)', '=IFERROR(ROUND(MAX(FILTER(' + L + '!G2:G,' + L + '!D2:D="duur"))/60,1),0)'],
    ['Aanvragen aanschaf', '=IFERROR(MAX(COUNTA(' + BLAD_AANSCHAF + '!A2:A),0),0)'],
    ['Aanvragen kantoor', '=IFERROR(MAX(COUNTA(' + BLAD_KANTOOR + '!A2:A),0),0)']
  ];

  blad.getRange(4, 1, regels.length, 1).setValues(regels.map(function (r) { return [r[0]]; }));
  blad.getRange(4, 2, regels.length, 1).setFormulas(regels.map(function (r) { return [r[1]]; }));

  blad.getRange('A14').setValue('Bezoeken per blok').setFontWeight('bold');
  blad.getRange('A15').setFormula(
    '=IFERROR(QUERY(' + L + '!D2:E,"select E, count(E) where D = \'blok\' group by E order by count(E) desc label E \'Blok\', count(E) \'Geopend\'",0),"nog geen gegevens")'
  );

  blad.getRange('D14').setValue('Schilderijen aan de muur bekeken').setFontWeight('bold');
  blad.getRange('D15').setFormula(
    '=IFERROR(QUERY(' + L + '!D2:E,"select E, count(E) where D = \'werk\' group by E order by count(E) desc label E \'Schilderij\', count(E) \'Keer bekeken\'",0),"nog geen gegevens")'
  );

  blad.setColumnWidth(1, 260);
  blad.setColumnWidth(2, 120);
  blad.setColumnWidth(4, 260);
  blad.setColumnWidth(5, 120);
}

function jsonAntwoord(object) {
  return ContentService
    .createTextOutput(JSON.stringify(object))
    .setMimeType(ContentService.MimeType.JSON);
}
